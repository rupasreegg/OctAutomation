package UtilisPackage;

import BasePackage.BaseClass;

public class Utilis extends BaseClass {
    public static long PAGE_LOAD_TIMEOUT=30;
    public static long IMPLICIT_WAIT=30;
}
